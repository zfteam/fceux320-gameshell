#ifndef WIN_PALETTE_H
#define WIN_PALETTE_H

void ConfigPalette();
bool SetPalette(const char* nameo);

#endif

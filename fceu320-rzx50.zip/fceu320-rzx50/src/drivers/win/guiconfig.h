#ifndef WIN_GUICONFIG_H
#define WIN_GUICONFIG_H

#include "common.h"

void ConfigGUI();

#endif

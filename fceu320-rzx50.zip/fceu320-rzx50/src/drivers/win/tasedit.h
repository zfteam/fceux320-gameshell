#include "movie.h"

void DoTasEdit();
void UpdateTasEdit();
void CreateProject(MovieData data);
void InvalidateGreenZone(int after);

#include <string>
// Open a help window to the default topic, or to ::/subpage.htm
void OpenHelpWindow(std::string subpage = "");

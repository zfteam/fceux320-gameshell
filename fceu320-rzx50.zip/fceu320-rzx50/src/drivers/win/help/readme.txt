You can find the source project (HelpNDoc3 file) to compile this chm here:
\fceux\fceu\vc\Help\fceux.hnd

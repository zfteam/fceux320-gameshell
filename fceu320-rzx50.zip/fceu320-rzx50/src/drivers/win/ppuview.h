extern int PPUViewScanline;
extern int PPUViewer;
extern int scanline;
void DoPPUView();
void PPUViewDoBlit();


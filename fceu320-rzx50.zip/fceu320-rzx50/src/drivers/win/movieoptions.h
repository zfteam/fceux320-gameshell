void OpenMovieOptions();

extern int pauseAfterPlayback;